#Roadmap


To Do:

 * Add speed options
 * Make add menu options more granular